var test = 111;

function a() {
    console.log("aa", this.test);
    this.test = 222;
}
a();
console.log("bb", this.test);

function b() {
    this.test = 333;
    console.log("cc", window.test);
}
b();

console.log("dd", this.test);